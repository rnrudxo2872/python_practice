import requests
from bs4 import BeautifulSoup

inscrap = requests.get("https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=맛집")

#print(inscrap)

soup = BeautifulSoup(inscrap.text,'html.parser')

#print(soup)

page_wrap = soup.find('div',{'class':'api_sc_page_wrap'});

#print(page_wrap)

page_link = page_wrap.find_all('a')

page_num = []
for page in page_link :
  page_num.append(page);

print(page_num[-1])